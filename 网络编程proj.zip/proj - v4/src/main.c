#include "chat.h"
#include "user_list.h"
#include "check_input.h"

int broad_sockfd;
int single_sockfd;
int multi_sockfd;
char myself_name[128];

void ctrl_C_fun(int arg)
{
    broadcast_myself_info(&broad_sockfd,0);
    printf("exit success!\n");
    exit(0);
}

// void *count_time_fun(void *arg);

int main()
{
    signal(SIGINT,ctrl_C_fun);

    head = list_init();

    struct user_info *single = malloc(sizeof(struct user_info));
    broad_sockfd = broad_sockfd_init();
    multi_sockfd = multi_sockfd_init();
    single_sockfd = single_sockfd_init();
    single->sockfd = single_sockfd;
    strcpy(single->ip,"192.168.23.102");
    single->port = SINGLE_PORT;
    

    broadcast_myself_info(&broad_sockfd,1);
    int time = 1;
    pthread_t count_time;
    pthread_create(&count_time,NULL,count_time_fun,(void *)&time);

    pthread_join(count_time,NULL);

    pthread_t tid[3];
    pthread_create(&tid[0],NULL,broad_recv_fun,&broad_sockfd);
    pthread_create(&tid[1],NULL,single_recv_fun,single); 
    pthread_create(&tid[2],NULL,multi_recv_fun,&multi_sockfd);

    printf("init success!\n");

    int cmd,ret;
    char ip[20];
    char name[128];
    char arr[20];
    struct user_info account;
    while(1)
    {
        while(1)        //cmd
        {
            printf("\t\t\t\033[0;33mYOUR CHOICE\033[0m\n"\
            "==================================================================\n"\
                "||\t\033[34m1、single\t\033[0m2、broadcast\t\033[34m3、multicast\033[0m\t\t||\n"\
                "||\t4、show list\t\033[34m5、find user\t\033[0m6、transmition file\t||\n");
            ret = esc_check_number(arr);
            if(ret == -1)
            {
                broadcast_myself_info(&broad_sockfd,0);
                printf("exit success!\n");
                exit(0);
            }
            if(ret == 1)
            {
                cmd = atoi(arr);
                break;
            }
            else{
                printf("cmd is wrong!\n");
            }
        }
        if(cmd == 1)
        {
            while(1)
            {
                printf("please input user's ip_address:\n");
                ret = esc_check_number(arr);
                if(ret == -1)
                {
                    // while('\n'!=getchar());
                    break;
                }
                if(ret == 1)
                {
                    strcpy(single->ip,arr);
                    printf("send msg or file [0/1]\n");
                    if( scanf("%d",&cmd) )
                    {
                        break;
                    }
                    if(cmd == 0 || cmd ==1)
                    {
                        single_send_fun(single,cmd);
                    }
                    else
                        printf("wrong choice [msg or file]\n");
                    break;
                }
                else{
                    printf("wrong ip!\n");
                }
            }
        }
        if(cmd == 2)
        {
            broad_send_fun(&broad_sockfd);
        }
        if(cmd == 3)
        {
            multi_send_fun(&multi_sockfd);
        }
        if(cmd == 4)
        {
            show_user_info_list(head);
        }
        if(cmd == 5)
        {
            printf("user's ip\n");
            if( esc_getchar(ip,sizeof(ip)) != 1 )
            {
                continue;
            }
            printf("user's name\n");
            if( esc_getchar(name,sizeof(name)) != 1 )
            {
                continue;
            }
            find_user_info(head,ip,name,&account,true);
        }
        if(cmd == 6)
        {
            
        }
        else
        {
            printf("wrond cmd!\n");
        }
    }


    int i=0;
    while(i<3)
    {
        pthread_join(tid[i],NULL);
        i++;
    }

}
