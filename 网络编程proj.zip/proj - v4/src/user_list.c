#include "../include/user_list.h"


//init user list head
struct user_info * list_init()
{
    head = malloc(sizeof(struct user_info));
printf("%d\n",__LINE__);
    if(head == NULL)
    {
        perror("init head");
        exit(1);
    }
    bzero(&head->name,sizeof(head->name));
    bzero(&head->ip,sizeof(head->ip));
    head->port = 0;
    INIT_LIST_HEAD( &head->list );
    return head;
}

//add new node into list tail
bool add_new_user_node_to_list_tail(struct user_info* head,struct user_info * accont)
{
    if(head == NULL)
    {
        printf("without head!\n");
        return false;
    }
    
    struct user_info *new = malloc(sizeof(struct user_info));
    
    //get val
    strcpy(new->name, accont->name);
    strcpy(new->ip, accont->ip);
    new->port = accont->port;

    //add node to list tail
    list_add_tail( &(new->list), &(head->list) );

    printf("add user info to list success!\n");
    return true;
}

//查找节点信息
bool find_user_info(struct user_info * head,char *ip,char *name,struct user_info *q,bool choice)
{
    if( list_empty( &(head->list) ) )
    {
        printf("empty list\n");
        return false;
    }
    if(ip == NULL && name == NULL)
    {
        printf("argument is wrong!\n");
        return false;
    }
    struct user_info * p = head;
    if(ip!=NULL)
    {
        list_for_each_entry(p, &(head->list), list)
        {
            if( !strcmp(p->ip,ip) )
            {
                printf("find it!\n");
                if(q!=NULL)
                {
                    q=p;
                }
                if(choice == true)
                {
                    printf("[NAME]%s\t[IP]%s\t[PORT]%d\n",p->name,p->ip,p->port);
                }
                return true;
            }
        }
    }

    if(name!=NULL)
    {
        list_for_each_entry(p, &(head->list), list)
        {
            if( !strcmp(p->name,name) )
            {
                printf("find it!\n");
                if(q!=NULL)
                {
                    q=p;
                }
                if(choice == true)
                {
                    printf("[NAME]%s\t[IP]%s\t[PORT]%d\n",p->name,p->ip,p->port);
                }
                return true;
            }
        }        
    }
    printf("No such ip!\n");
    printf("No such name!\n");
    return false;
}

//删除对应节点
bool remove_user_info_node(struct user_info * head,struct user_info *node)
{
    if( list_empty( &(head->list) ) )
    {
        printf("empty list\n");
        return false;
    }
    struct user_info *p = head;
    struct user_info *q = head;
    list_for_each_entry_safe(p, q, &(head->list), list)
    {
        if( !strcmp( node->ip,p->ip) && node->port == p->port )
        {
            printf("find it and removing...\n");
            list_del( &(p->list) );
            free(p);
            printf("remove success!\n");
            return true;
        }
    }
    printf("No result to remove\n");
    return false;
}

//摧毁链表
bool destroy_user_info_list(struct user_info * head)
{
    if( list_empty( &(head->list) ) )
    {
        printf("empty list\n");
        return false;
    }
    struct user_info *p = head;
    struct user_info *q = head;
    list_for_each_entry_safe(p, q, &(head->list), list)
    {
        list_del( &(p->list) );
        free(p);
    }
    free(head);
}

//显示链表
bool show_user_info_list(struct user_info * head)
{
    if( list_empty( &(head->list) ) )
    {
        printf("empty list\n");
        return false;
    }

    struct user_info * p = head;
    list_for_each_entry(p, &(head->list), list)
    {
        printf("============================\n");
        printf("name:%s\n",p->name);
        printf("[IP]%s\t[PORT]%d\n",p->ip,p->port);
    }
    return true;
}

