#include "../include/other.h"


#define BUF_SIZE 2048

//文件路径以buf参数传进来  进行复制copy
void * send_file(void *node)
{
    //新旧文件路径赋值
    char pathbuffer1[strlen( ((struct node*)node)->DIRPATH1 )+strlen( ((struct node*)node)->dir->d_name )+2];
    sprintf(pathbuffer1,"%s/%s", ((struct node*)node)->DIRPATH1 , ((struct node*)node)->dir->d_name);
    //打开旧文件
    FILE *fp=fopen(pathbuffer1,"r");
    if(fp==NULL)
    {
        perror("open file inside");
        return NULL;
    }

    //进行复制
    char data[BUF_SIZE]={0};
    int ret;
    extern int single_sockfd;
    //      读取旧文件信息
    while( ret=fread(data,1,BUF_SIZE,fp) )
    {
        sendto(single_sockfd,data,strlen(data),0,(const struct sockaddr*)&( ((struct node*)node)->other_addr ),sizeof(struct sockaddr));
    }
    // printf("strlen1s : %ld\n",strlen(data));
    printf("[%s]已完成\n",pathbuffer1);
    fclose(fp);
    free(node);
}



//读文件夹并丢入线程池
void read_dir(struct node *node)
{
    //打开文件夹
    DIR *dirp1=opendir(node->DIRPATH1);
    if(dirp1==NULL){
        perror("open file");
        return;
    }

    struct node *buf_inside = malloc(sizeof(struct node));
    while ( node->dir = readdir(dirp1) )
    {
        //找到一个文件夹
        if(node->dir->d_type==DT_DIR && strcmp(node->dir->d_name,".")!=0 && strcmp(node->dir->d_name,"..")!=0 )
        {
            char pathbuffer1[strlen(node->DIRPATH1)+strlen(node->dir->d_name)+2];
            sprintf(pathbuffer1,"%s/%s",node->DIRPATH1,node->dir->d_name);

/*             printf("[ ]创建文件夹\n");

            int flag = mkdir(pathbuffer2,777);
            if(flag<0)
            {
                perror("mkdir");
                return;
            } */

            //复制文件夹路径
            strcpy(buf_inside->DIRPATH1 ,pathbuffer1);
            //递归打开文件
            read_dir(buf_inside);
        }
        //找到一个非文件夹类型的文件
        else if( node->dir->d_type!=DT_DIR )
        {
            //创建结构体存放文件信息
            struct node *new = malloc(sizeof(struct node));
            new->dir = node->dir;
            strcpy(new->DIRPATH1,node->DIRPATH1);
            new->other_addr = node->other_addr;
            // printf("new : %s/%s\n",new->DIRPATH1,new->dir->d_name);
            // char filename[512];
            // sprintf(filename,"%s/%s",new->DIRPATH1,new->dir->d_name);
            
            /* //获取文件大小
            struct stat statbuf;
            int ret = stat(filename,&statbuf);
            if(ret != 0)
            {
                perror("stat file size");
                return ;
            }
            p_bar.total_file_size += statbuf.st_size;
 */
            
            
            //投放任务
            send_file(new);

        }
    }
    sleep(1);

    closedir(dirp1);

    return;
}





//recv
void * send_file(void *node)
{
    //新旧文件路径赋值
    char pathbuffer1[strlen( ((struct node*)node)->DIRPATH1 )+strlen( ((struct node*)node)->dir->d_name )+2];
    char pathbuffer2[strlen( ((struct node*)node)->DIRPATH2 )+strlen( ((struct node*)node)->dir->d_name )+2];
    sprintf(pathbuffer1,"%s/%s", ((struct node*)node)->DIRPATH1 , ((struct node*)node)->dir->d_name);
    sprintf(pathbuffer2,"%s/%s", ((struct node*)node)->DIRPATH2 , ((struct node*)node)->dir->d_name);
    //打开旧文件
    FILE *fp=fopen(pathbuffer1,"r");
    if(fp==NULL)
    {
        perror("open file inside");
        return NULL;
    }
    //打开（创建新文件）
    FILE *fp1=fopen(pathbuffer2,"w");
    if(fp1==NULL)
    {
        perror("open new file");
        return 0;
    }

    //进行复制
    char data[BUF_SIZE]={0};
    int ret;
    //      读取旧文件信息
    while( ret=fread(data,1,BUF_SIZE,fp) )
    {
        //锁上//修改变量
        pthread_mutex_lock(&mutex);
        //写入新文件
        fwrite(data,ret,1,fp1);
        //解锁
        pthread_mutex_unlock(&mutex);
    }
    // printf("strlen1s : %ld\n",strlen(data));
    printf("[%s]已完成\n",pathbuffer1);
    fclose(fp);
    fclose(fp1);
    free(node);
}





