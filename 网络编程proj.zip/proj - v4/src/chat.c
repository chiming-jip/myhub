#include "chat.h"


void *recv_fun(void *arg)
{
    int sockfd = socket(AF_INET,SOCK_DGRAM,0);
    if(sockfd < 0)
    {
        perror("socket");
        return 0;
    }

    struct sockaddr_in my_addr,other_addr;
    memset(&my_addr,0,sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    my_addr.sin_port = htons(BROAD_PORT);

    socklen_t len = sizeof(my_addr);
    int on = 1;
    setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&on,sizeof(on));

    if( bind(sockfd ,(const struct sockaddr*)&my_addr,sizeof(my_addr))  )
    {
        perror("bind    ");
        return 0;
    }
    char buf[1024];
    char ip_arr[20];
    while(1)
    {
        bzero(buf,sizeof(buf));
        recvfrom(sockfd,buf,sizeof(buf),0,(struct sockaddr*)&other_addr,&len );
        printf("[Broad][IP:%s PORT:%d] : %s\n",inet_ntop(AF_INET,&other_addr.sin_addr,ip_arr,len) ,ntohs(other_addr.sin_port),buf);
    }
}
void *send_fun(void *arg)
{
    int sockfd = socket(AF_INET,SOCK_DGRAM,0);
    if(sockfd < 0)
    {
        perror("sock");
        return 0;
    }

    int on = 1;
    setsockopt(sockfd,SOL_SOCKET,SO_BROADCAST,&on,sizeof(on));

    struct sockaddr_in   other_addr,my_addr;
    memset(&other_addr,0,sizeof(other_addr));
    other_addr.sin_family = AF_INET;
    other_addr.sin_addr.s_addr = inet_addr(BROAD_ADDR);
    other_addr.sin_port = htons(BROAD_PORT);
    socklen_t len = sizeof(other_addr);

    char buf[1024];

    while(1)
    {
        fgets(buf,sizeof(buf),stdin);
        sendto(sockfd,buf,strlen(buf),0,(const struct sockaddr*)&other_addr,len);
        bzero(buf,sizeof(buf));
    }
}



void get_local_ip_addr(char * ip_arr)
{
    struct ifaddrs *ifaddr, *ifa;
    int family, s;

    if(getifaddrs(&ifaddr) == -1)
    {
        perror("getifaddrs (get local ip addr failed)");
        exit(EXIT_FAILURE);
    }

    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
       if (ifa->ifa_addr == NULL)
           continue;

        family = ifa->ifa_addr->sa_family;

        if (family == AF_INET)
        {
            if( !strcmp(ifa->ifa_name,"eth0") || !strcmp(ifa->ifa_name,"ens33") )
            {
                // printf("interfac: %s, ip: %s\n", ifa->ifa_name, inet_ntoa(((struct sockaddr_in*)ifa->ifa_addr)->sin_addr));
                sprintf(ip_arr,"%s", inet_ntoa(((struct sockaddr_in*)ifa->ifa_addr)->sin_addr) );
            }
            // printf("interfac: %s, ip: %s\n", ifa->ifa_name, inet_ntoa(((struct sockaddr_in*)ifa->ifa_addr)->sin_addr));
        }
   }
   freeifaddrs(ifaddr);
}


//broadcast
void *broad_send_fun(void *arg)
{
    int sockfd = *(int*)arg;

    struct sockaddr_in   other_addr,my_addr;
    memset(&other_addr,0,sizeof(other_addr));
    other_addr.sin_family = AF_INET;
    other_addr.sin_addr.s_addr = inet_addr(BROAD_ADDR);
    other_addr.sin_port = htons(BROAD_PORT);
    socklen_t len = sizeof(other_addr);

    char buf[1024];
    printf("ready to broadcast!\n");
	int ret;
    while(1)
    {
        while(1)
		{
			ret = esc_getchar(buf,BUF_SIZE);
			if(ret == -1)
			{
				return 0;
			}
			if(ret == 1)
			{
				break;
			}
			else
			{
				printf("wrong buf!\n");
			}	
		}
        sendto(sockfd,buf,strlen(buf),0,(const struct sockaddr*)&other_addr,len);
        printf("send msg success!\n");
        bzero(buf,sizeof(buf));
    }
}

void *broad_recv_fun(void *arg)
{
    int sockfd = *(int *)arg;

    extern int single_sockfd;
    extern char myself_name[128];

    struct sockaddr_in other_addr;
    socklen_t len = sizeof(other_addr);

    char buf[1024];
    char ip_arr[20];
    struct user_info *account;
    while(1)
    {
        // printf("come here yet! go on ! just do it!\n");
        bzero(buf,sizeof(buf));
        recvfrom(sockfd,buf,sizeof(buf),0,(struct sockaddr*)&other_addr,&len );
        if( !strncmp(buf,"[ON_LINE]",9) )
        {
            // printf("someone is on_line\n");
            account = malloc(sizeof(struct user_info));
            sscanf(buf,"[ON_LINE]%s %d %s",account->ip,&account->port,account->name);
            get_local_ip_addr(ip_arr);
            if( true == find_user_info(head,account->ip,account->name,NULL,false) )
            {
                continue;
            }
            printf("\nnew client\n[IP]:%s\n[PORT]:%d\n[name]:%s\n",account->ip,account->port,account->name);
            add_new_user_node_to_list_tail(head,account);
            
            sprintf(buf,"[ON_LINE]%s %d %s",ip_arr,SINGLE_PORT,myself_name);
            sendto(single_sockfd,buf,sizeof(buf),0,(const struct sockaddr*)&other_addr,sizeof(other_addr));
            free(account);
        }
        else if( !strncmp(buf,"[OUT_LINE]",10) )
        {
            account = malloc(sizeof(struct user_info));
            sscanf(buf,"[OUT_LINE]%s %d %s",account->ip,&account->port,account->name);
            remove_user_info_node(head,account);
            printf("[IP]%s\t[PORT]%d\t[NAME]%s\tis out line\n",account->ip,account->port,account->name);
            free(account);
        }
        else
            printf("[Broad][IP:%s PORT:%d] : %s\n",inet_ntop(AF_INET,&other_addr.sin_addr,ip_arr,len) ,ntohs(other_addr.sin_port),buf);
    }
}

int broad_sockfd_init()
{
    int sockfd = socket(AF_INET,SOCK_DGRAM,0);
    if(sockfd < 0)
    {
        perror("socket");
        return 0;
    }

    struct sockaddr_in my_addr,other_addr;
    memset(&my_addr,0,sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    // my_addr.sin_addr.s_addr = inet_addr("192.168.23.102");
    my_addr.sin_port = htons(BROAD_PORT);

    socklen_t len = sizeof(my_addr);
    int on = 1;
    setsockopt(sockfd,SOL_SOCKET,SO_REUSEADDR,&on,sizeof(on));
    setsockopt(sockfd,SOL_SOCKET,SO_BROADCAST,&on,sizeof(on));

    if( bind(sockfd ,(const struct sockaddr*)&my_addr,sizeof(my_addr))  )
    {
        perror("bind    ");
        return 0;
    }
    printf("broadcast init success!\n");
    return sockfd;
}


//single
void *single_send_fun(void *arg,int cmd)
{
    int msg_or_file = cmd;
    int sockfd = ( (struct user_info*)arg )->sockfd;
    if(sockfd < 0)
    {
        perror("single sock send");
        return 0;
    }

    struct sockaddr_in   other_addr;

    memset(&other_addr,0,sizeof(other_addr));
    other_addr.sin_family = AF_INET;
    other_addr.sin_addr.s_addr = inet_addr( ( (struct user_info*)arg )->ip );
    other_addr.sin_port = htons( ((struct user_info *)arg)->port );
    socklen_t len = sizeof(other_addr);

    char buf[BUF_SIZE];
	int ret;
    if(msg_or_file == 0)
    {
        printf("ready to single send msg\n");
        while(1)
        {
            while(1)
            {
                ret = esc_getchar(buf,BUF_SIZE);
                if(ret == -1)
                {
                    // while('\n'!=getchar);
                    return 0;
                }
                if(ret == 1)
                {
                    break;
                }
                else
                {
                    printf("wrong buf!\n");
                }	
            }
            sendto(sockfd,buf,strlen(buf),0,(const struct sockaddr*)&other_addr,len);
            bzero(buf,sizeof(buf));
        }
    }
    else if(msg_or_file == 1)
    {
        char file_path[1024];
        while(1){
            printf("input filename\n");
            ret = esc_getchar(file_path,sizeof(file_path));
            if( ret == -1 )
            {
                return 0;
            }
            if(ret == 1)
            {
                break;
            }
            else{
                printf("wrong filename!\n");
            }
        }

        sprintf(buf,"[file]%s",file_path);
        sendto(sockfd,buf,strlen(buf),0,(const struct sockaddr*)&other_addr,len);
        struct node *node = malloc(sizeof(struct node));
        read_dir(node);
        return 0;
    }
	
}

void *single_recv_fun(void *arg)
{
    int sockfd = ((struct user_info*)arg)->sockfd;

    struct sockaddr_in other_addr;
    socklen_t len = sizeof(other_addr);

    char buf[1024];
    char ip_arr[20];
    struct user_info *account;
    while(1)
    {
        bzero(buf,sizeof(buf));
        recvfrom(sockfd,buf,sizeof(buf),0,(struct sockaddr*)&other_addr,&len );
        inet_ntop(AF_INET,&other_addr.sin_addr,ip_arr,len);
        if( !strncmp(buf,"[ON_LINE]",9) )
        {
            // printf("[single]someone is on_line\n");
            account = malloc(sizeof(struct user_info));
            sscanf(buf,"[ON_LINE]%s %d %s",account->ip,&account->port,account->name);
            get_local_ip_addr(ip_arr);
            if( true == find_user_info(head,account->ip,account->name,NULL,false) )
            {
                continue;
            }
            add_new_user_node_to_list_tail(head,account);
            free(account);
        }
        else if( !strncmp(buf,"[file]",6) )
        {
            
        }
        else
            printf("[Single][IP:%s PORT:%d] : %s\n", ip_arr,ntohs(other_addr.sin_port),buf);
    }
}

int single_sockfd_init()
{
    int sockfd = socket(AF_INET,SOCK_DGRAM,0);
    if(sockfd < 0)
    {
        perror("socket");
        return 0;
    }

    struct sockaddr_in  my_addr ;
    memset(&my_addr,0,sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    my_addr.sin_port = htons(SINGLE_PORT);
    socklen_t len = sizeof(my_addr);
    
    if( bind(sockfd,(const struct sockaddr*)&my_addr,len) )
    {
        perror("bind");
        return 0;
    }

    return sockfd;
}


//multi
void *multi_send_fun(void *arg)
{
    int sockfd = *(int *)arg;
    if(sockfd < 0)
    {
        perror("socket");
        return 0;
    }

    struct sockaddr_in other_addr;
    memset(&other_addr,0,sizeof(other_addr));
    other_addr.sin_family = AF_INET;
    other_addr.sin_addr.s_addr = inet_addr(MULTI_ADDR);
    other_addr.sin_port = htons(MULTI_PORT);
    socklen_t len = sizeof(other_addr);

    char buf[BUF_SIZE];
	int ret;
	printf("ready to multicast\n");
    while(1)
    {
        while(1)
		{
			ret = esc_getchar(buf,BUF_SIZE);
			if(ret == -1)
			{
				return 0;
			}
			if(ret == 1)
			{
				break;
			}
			else
			{
				printf("wrong buf!\n");
			}	
		}
        sendto(sockfd,buf,strlen(buf),0,(const struct sockaddr*)&other_addr,len);
        bzero(buf,sizeof(buf));
    }
}

void *multi_recv_fun(void *arg)
{
    int sockfd = *(int *)arg;
    
    struct sockaddr_in other_addr;
    memset(&other_addr,0,sizeof(other_addr));
    socklen_t len = sizeof(other_addr);

    char buf[BUF_SIZE];
    char ip_arr[20];
    while(1)
    {
        bzero(buf,sizeof(buf));
        recvfrom(sockfd,buf,sizeof(buf),0,(struct sockaddr*)&other_addr,&len);
        printf("[Multi][IP:%s PORT:%d] : %s\n",inet_ntop(AF_INET,&other_addr.sin_addr,ip_arr,len) ,ntohs(other_addr.sin_port),buf);
    }
}

int multi_sockfd_init()
{
	//1)
    int sockfd= socket(AF_INET,SOCK_DGRAM,0);
    if(sockfd < 0)
    {
        perror("socket");
        return 0;
    }
	//2)
    struct sockaddr_in multi_addr;
    memset(&multi_addr,0,sizeof(multi_addr));
    multi_addr.sin_family = AF_INET;
    multi_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    multi_addr.sin_port = htons(MULTI_PORT);
    socklen_t len = sizeof(multi_addr);

    char ip_arr[20];
    get_local_ip_addr(ip_arr);
    printf("local ip:%s\n",ip_arr);
	
	//3)add into multi group
    struct ip_mreq M_addr;
    inet_pton(AF_INET, MULTI_ADDR,  &M_addr.imr_multiaddr);			//赋值组播地址
	inet_pton(AF_INET, ip_arr, &M_addr.imr_interface);		//赋值主机地址

	setsockopt(sockfd, IPPROTO_IP, IP_ADD_MEMBERSHIP, &M_addr, sizeof(M_addr));

	//4)
    if(bind(sockfd, (const struct sockaddr *)&multi_addr, len))
	{
		perror("bind failed");
		return 0;
	}	

    return sockfd;
}


// broadcast myself info to gain other users' info
void *broadcast_myself_info(void *arg,int a)
{
    int sockfd = *(int *)arg;

    struct sockaddr_in   other_addr,my_addr;
    memset(&other_addr,0,sizeof(other_addr));
    other_addr.sin_family = AF_INET;
    other_addr.sin_addr.s_addr = inet_addr(BROAD_ADDR);
    other_addr.sin_port = htons(BROAD_PORT);
    socklen_t len = sizeof(other_addr);

    char buf[1024];
    extern char myself_name[128];
    char ip_arr[20];
    get_local_ip_addr(ip_arr);    
    printf("[IP]:%s send it's info\n",ip_arr);
    if(a == 1)
    {
        int ret;
        while(1){
            printf("regist your name\n");
            ret = esc_getchar(myself_name,128);
            if(ret == -1)
                exit(1);
            if(ret == 1){
                break;
            }
            else{
                printf("your name is wrong!\n");
                while('\n'!=getchar());
            }
        }
        
        sprintf(buf,"[ON_LINE]%s %d %s",ip_arr,SINGLE_PORT,myself_name);
    }
    else
        sprintf(buf,"[OUT_LINE]%s %d %s",ip_arr,SINGLE_PORT,myself_name);
    sendto(sockfd,buf,strlen(buf),0,(const struct sockaddr*)&other_addr,len);
    printf("============================\nwating for other client info...\n=========================\n");
    bzero(buf,sizeof(buf));
}


void *count_time_fun(void *arg)
{
    int i = 0;
    while( i < *(int*)arg )
    {
        sleep(1);
        i++;
    }
}



void *send_file(void *arg)
{
    
}




