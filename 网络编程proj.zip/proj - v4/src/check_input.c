#include "../include/check_input.h"

/*******************************************************************
    atof()：将字符串转换为双精度浮点型值。
    atoi()：将字符串转换为整型值。
    atol()：将字符串转换为长整型值。
    strtod()：将字符串转换为双精度浮点型值，并报告不能被转换的所有剩余数字。
    strtol()：将字符串转换为长整值，并报告不能被转换的所有剩余数字。
    strtoul()：将字符串转换为无符号长整型值，并报告不能被转换的所有剩余数字。
**********************************************************************/


//输入数字过程中按esc可退出当前程序 （不能接收空格与回车符）
// 使用方法: (以整形为例)传进一个数组，再用一个数接收 atoi(array) 的返回值
//返回值-1为esc  返回值1为成功
int esc_check_number(char *array)
{
    char buff;
    int subscript=0;
    while (1)
    {
        buff=getchar();
        //ESC按键情况
        if(buff == 27)
        {
            //清空字符串内容
            array[0]='\0';
            while('\n'!=getchar());
            return -1;
        }
        //回车按键情况 成功
        if(buff == '\n')
        {
            //字符串末尾加结束符
            array[subscript]='\0';
            return 1;
        }
        
        if( buff >= 48 && buff <= 57 || buff == '.')
        {
            //给字符串对应下标赋值
            array[subscript]=buff;
            subscript++;
        }
        //字母 空格键或其他非数字情况
        else
        {
            array[0]='\0';
            while('\n'!=getchar());
            break;
        }
    }
    return 0;   
}


//输入字符过程中按esc可退出当前程序 （可以接收空格,不能接收回车符）
//返回值-1为esc  返回值1为成功
int esc_getchar(char *array,int size)
{
    //下标
    int subscript=0;
    char buff;
    
    while (1)
    {
        if(size-1 <= subscript )
        {
            printf("超出范围\n");
            break;
        }
        buff=getchar();
        //ESC按键情况
        if(buff == 27)
        {
            array[0]='\0';
            while('\n'!=getchar());
            return -1;
        }
        //回车按键情况 成功
        if(buff == '\n')
        {
            array[subscript]='\0';
            return 1;
        }
        else
        {
            array[subscript]=buff;
            subscript++;
        }
    }
    return 0;   
}


