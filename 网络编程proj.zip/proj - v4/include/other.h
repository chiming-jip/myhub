#ifndef _OTHER_H_
#define _OTHER_H_

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include "chat.h"

struct node
{
    char DIRPATH1[256];
    struct dirent * dir ;
    struct sockaddr other_addr;
};

struct progress_bar
{
    unsigned total_file_size;
    unsigned already_read_file_size;
}p_bar;

bool die;

pthread_mutex_t mutex;



void read_dir(struct node *buf);

void * send_file(void *buf);






#endif