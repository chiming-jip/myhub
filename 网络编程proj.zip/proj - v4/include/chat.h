#ifndef CHECK_H_
#define CHECK_H_


#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdbool.h>
#include <ifaddrs.h>

#include <sys/ioctl.h>
#include "user_list.h"
#include "check_input.h"
#include "other.h"

#define BROAD_PORT 19999
#define MULTI_PORT 18888
#define SINGLE_PORT 17777
#define BROAD_ADDR "192.168.23.255"
#define MULTI_ADDR	"224.0.0.10"		//多播组IP



#define BUF_SIZE        1024        //buf size
#define FILENAME_SIZE   1024


void *recv_fun(void *arg);
void *send_fun(void *arg);



void get_local_ip_addr(char * ip_arr);



void *broad_send_fun(void *arg);

void *broad_recv_fun(void *arg);

int broad_sockfd_init();



void *single_send_fun(void *arg,int cmd);

void *single_recv_fun(void *arg);

int single_sockfd_init();



void *multi_send_fun(void *arg);

void *multi_recv_fun(void *arg);

int multi_sockfd_init();




void *broadcast_myself_info(void *arg,int a);

void *count_time_fun(void *arg);


#endif