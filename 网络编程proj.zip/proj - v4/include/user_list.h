#ifndef USER_LIST_H_
#define USER_LIST_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>
#include "kernel_list.h"


//user_info  struct 
struct user_info
{
    int sockfd;
    char name[128];
    char ip[16];
    int  port;
    struct list_head list;
}*head;

//init user list head
struct user_info * list_init();

//add new node into list tail
bool add_new_user_node_to_list_tail(struct user_info* head,struct user_info * accont);

//查找节点信息
bool find_user_info(struct user_info * head,char *ip,char *name,struct user_info *q,bool choice);

//删除对应节点
bool remove_user_info_node(struct user_info * head,struct user_info *node);

//摧毁链表
bool destroy_user_info_list(struct user_info * head);

//显示链表
bool show_user_info_list(struct user_info * head);

#endif