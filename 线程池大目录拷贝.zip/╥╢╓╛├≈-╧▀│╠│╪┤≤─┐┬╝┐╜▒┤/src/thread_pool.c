#include "thread_pool.h"

// #define bar

pthread_mutex_t exit_lock;
pthread_mutex_t wait_lock;
unsigned count_total_time=0;

//开锁再死
void handler(void *arg)
{
    //响应取消请求之后自动处理的例程：释放互斥锁
    pthread_mutex_unlock((pthread_mutex_t*)arg);
}

//线程例程(每个线程都要做的事)
void *routine(void *arg)
{
    thread_pool *pool = (thread_pool*)arg;
    struct task *p;

    while(1)
    {
        //访问任务队列前加锁，为防止取消后死锁，注册处理例程handler
        pthread_cleanup_push(handler,(void*)&pool->lock);
        pthread_mutex_lock(&pool->lock);

        //若当前没有任务，且线程池未关闭，则进入条件变量等待队列睡眠
        while(pool->waiting_tasks == 0 && !pool->shutdown)
        {
            // pthread_mutex_lock(&wait_lock);
            pool->waiting_thread_num++;
            // pthread_mutex_unlock(&wait_lock);

            // printf("我进来睡觉了, %d\n",pool->waiting_thread_num);
            pthread_cond_wait(&pool->cond,&pool->lock);
            // pthread_mutex_lock(&wait_lock);
            pool->waiting_thread_num--;
            // pthread_mutex_lock(&wait_lock);
            // printf("我出来了, %d\n",pool->waiting_thread_num);
        }

        //若当前没有任务，且线程池关闭标识为真，则立即释放互斥锁并退出
        if(pool->waiting_tasks == 0 && pool->shutdown == true)
        {
            pthread_mutex_lock(&exit_lock);
            pool->exited_thread_num++;
            pthread_mutex_unlock(&exit_lock);
            // printf("我退出了\n");
            pthread_mutex_unlock(&pool->lock);
            pthread_exit(NULL);
        }

        //执行任务，并且在此期间禁止响应取消请求
        pthread_setcancelstate(PTHREAD_CANCEL_DISABLE,NULL);

        //若当前有任务，则消费任务队列中的任务
        p=pool->task_list->next;
        pool->task_list->next = p->next;
        pool->waiting_tasks--;

        //释放互斥锁，并弹栈handler（但不执行他）
        pthread_mutex_unlock(&pool->lock);
        pthread_cleanup_pop(0);

        
        (p->task)(p->arg);
        pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
        
        free(p);
    }
    printf("居然跳出了死循环\n");
    pthread_exit(NULL);
}

//线程初始化
bool init_pool(thread_pool* pool,unsigned int threads_number)
{
    pthread_mutex_init(&pool->lock,NULL);
    pthread_cond_init(&pool->cond,NULL);
    pool->shutdown = false;     //关闭销毁线程池标识
    pool->task_list = malloc(sizeof(struct task));      //任务队列头节点
    pool->tids = malloc(sizeof(pthread_t)*MAX_ACTIVE_THREADS);

    if(pool->task_list == NULL || pool->tids == NULL)
    {
        perror("allocate memory error");
        return false;
    }

    pool->task_list->next = NULL;

    pool->waiting_thread_num = 0;
    pool->waiting_tasks  = 0;
    pool->active_threads = threads_number;
    pool->exited_thread_num = 0;
    int i;

    for ( i = 0; i < pool->active_threads; i++)
    {

        if( pthread_create(&((pool->tids)[i]),NULL,routine,(void*)pool) !=0)
        {
            perror("creat threads error");
            return false;
        }
    }

    return true;

}

//投放任务
bool add_task(thread_pool *pool,void *(*task)(void *arg),void *arg)
{
    struct task *new_task = malloc(sizeof(struct task));    //新任务节点
    if(new_task == NULL)
    {
        perror("allocate memory error");
        return false;
    }
    new_task->task = task;
    new_task->arg = arg;
    new_task->next = NULL;

    //访问任务队列前获取互斥锁，此处无需注册取消处理例程
    pthread_mutex_lock(&pool->lock);
    if(pool->waiting_tasks >= MAX_WAITING_TASKS)
    {
        pthread_mutex_unlock(&pool->lock);

        fprintf(stderr,"too many tasks.\n");
        free(new_task);

        return false;
    }

    struct task* tmp = pool->task_list;
    while(tmp->next != NULL)
        tmp = tmp->next;
    tmp->next = new_task; //添加新的任务节点
    pool->waiting_tasks++;

    //释放互斥锁，并唤醒其中一个阻塞在条件变量上的线程
    pthread_mutex_unlock(&pool->lock);
    pthread_cond_signal(&pool->cond);

    return true;
}

//增加线程
int add_thread(thread_pool *pool,unsigned additional_threads)
{
    if(additional_threads == 0)
    {
        return 0 ;
    }
    unsigned total_threads = pool->active_threads + additional_threads;

    int i, actual_increment = 0;
    for(i = pool->active_threads;i<total_threads && i<MAX_ACTIVE_THREADS;i++)   //循环地创建若干指定数目的线程
    {
        if(pthread_create(&((pool->tids)[i]),NULL,routine,(void *)pool)!=0)
        {
            perror("add threads error");
            if(actual_increment == 0)
            {
                return -1;
            }
            break;
        }
        actual_increment++;
    }
    pool->active_threads += actual_increment;
    return actual_increment;
}

//删除线程
int remove_thread(thread_pool *pool,unsigned int removing_threads)
{
    if(removing_threads == 0)
    {
        return pool->active_threads;
    }

    

    int remain_threads = pool->active_threads - removing_threads;
    remain_threads = remain_threads > 0 ? remain_threads : 1;

    

    int i;   //循环地取消掉指定数目的线程
    for(i=pool->active_threads-1;i>remain_threads-1;i--)
    {
        errno = pthread_cancel(pool->tids[i]);
        if(errno != 0)
        {
            break;
        }
        //加锁，
        pthread_mutex_lock(&wait_lock);
        pool->waiting_thread_num--;
        //解锁
        pthread_mutex_lock(&wait_lock);

    }   
    

    if(i == pool->active_threads-1)
    {
        return -1;
    }
    else
    {
        printf("删除成功\n");
        pool->active_threads= i+1;
        return i+1;
    }
}

//销毁线程池
bool destroy_pool(thread_pool *pool)
{
    pool->shutdown = true;
    pthread_cond_broadcast(&pool->cond);

    int i;
    for(i = 0;i<pool->active_threads;i++)
    {
        errno = pthread_join(pool->tids[i],NULL);
        if(errno != 0)
        {
            printf("join tids[%d] error : %s\n",i,strerror(errno));
        }
        else
        {
            printf("[%u] is joined(destroy)\n",(unsigned)pool->tids[i]);
            // pthread_mutex_lock(&exit_lock);
            // printf("前：%d\n",pool->exited_thread_num);
            pool->exited_thread_num -= 1;
            // printf("后：%d\n",pool->exited_thread_num);
            // pthread_mutex_unlock(&exit_lock);
        }
    }
    free(pool->task_list);
    free(pool->tids);
    free(pool);

    return true;

}


//监控任务数量，以便增减线程
void *count_task_num(void *arg)
{
    // sleep(3);
    thread_pool *pool = (thread_pool *)arg;
    int i=0;
    while(1)
    {
        //任务多
        if(pool->waiting_thread_num <= 0 && pool->waiting_tasks > 0)
        {
            usleep(100);
            if(pool->waiting_thread_num <= 0 && pool->waiting_tasks > 0)
            {
                printf("增加一条线程\n");
                add_thread(pool,1);
            }
        }
        if(pool->waiting_thread_num > 1)
        {
            if(++i==5)
            {
                if(pool->waiting_thread_num > 1)
                {
                    printf("减少一条线程\n");
                    remove_thread(pool,1);
                    usleep(100000);
                }
                i=0;
            }
        }
        usleep(100);
    }  
}


//计时器
void *count_time(void* arg)
{
    thread_pool *pool = (thread_pool *)arg; 
    extern bool die;
    while(1)
    {
#ifdef bar
        if(die)
        {
            printf("\033[10;3H共用时 %d 秒\n",count_total_time);
            pthread_exit(NULL);
        }
        
#else
        printf("sec: %d\n",count_total_time);
        if(count_total_time%3==0)
        {
            printf("\n总线程数为：%d\n",pool->active_threads);
            printf("正在工作线程数为: %d\n",pool->active_threads-pool->exited_thread_num);
            printf("在等待的线程有 %d 条\n",pool->waiting_thread_num);
            printf("现有任务数为：%d\n",pool->waiting_tasks);
            printf("等待回收的进程数为：%d\n\n",pool->exited_thread_num);
        }
#endif
        sleep(1);
        count_total_time++;
    }
}



