#include "other.h"
#include "thread_pool.h"

// #define bar



int  main(int argc,char** argv)
{
    printf("\033[2J");
    if(argc < 3)return (-1);
    mkdir(argv[2],777);
#ifdef bar
    die = false;
#endif
    //进度条初始化并创建线程
    p_bar.already_read_file_size = 0;
    p_bar.total_file_size = 0;
    pthread_t pro_bar;
    pthread_create(&pro_bar,NULL,progress_bar,&p_bar);

    //创建文件信息的结构体
    struct node *buf = malloc(sizeof(struct node));
    strcpy(buf->DIRPATH1, argv[1]);
    strcpy(buf->DIRPATH2, argv[2]);


    //1,初始化一个带有1条线程的线程池
    thread_pool *pool = malloc(sizeof(thread_pool));
    if(pool == NULL)
    {
        perror("malloc pool");
        return 0;
    }
    init_pool(pool,1);
    
    //计时器
    pthread_t a;
    pthread_create(&a,NULL,count_time,pool);

    
    read_dir(buf,pool);

    //监测任务量，判断是否需要增减线程
    pthread_t task_num;
    pthread_create(&task_num,NULL,count_task_num,pool);

    //销毁线程池
    destroy_pool(pool);
    free(buf);
#ifdef bar
    pthread_cancel(pro_bar);
    pthread_join(pro_bar,NULL);
    die = true;
    sleep(1);
#endif
    
    // printf("共用时：%d\n",count_total_time);
    

    
    
    return 0;
}







