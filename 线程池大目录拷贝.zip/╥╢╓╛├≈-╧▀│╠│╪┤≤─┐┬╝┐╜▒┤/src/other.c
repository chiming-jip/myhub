#include "other.h"
#include "thread_pool.h"

// #define bar

#define BUF_SIZE 2048

//文件路径以buf参数传进来  进行复制copy
void * cp(void *buf)
{
    //新旧文件路径赋值
    char pathbuffer1[strlen( ((struct node*)buf)->DIRPATH1 )+strlen( ((struct node*)buf)->dir->d_name )+2];
    char pathbuffer2[strlen( ((struct node*)buf)->DIRPATH2 )+strlen( ((struct node*)buf)->dir->d_name )+2];
    sprintf(pathbuffer1,"%s/%s", ((struct node*)buf)->DIRPATH1 , ((struct node*)buf)->dir->d_name);
    sprintf(pathbuffer2,"%s/%s", ((struct node*)buf)->DIRPATH2 , ((struct node*)buf)->dir->d_name);
#ifndef bar
    printf("pathbuf1 : %s\n",pathbuffer1);
#endif
    //打开旧文件
    FILE *fp=fopen(pathbuffer1,"r");
    if(fp==NULL)
    {
        perror("open file inside");
        return NULL;
    }
    //打开（创建新文件）
    FILE *fp1=fopen(pathbuffer2,"w");
    if(fp1==NULL)
    {
        perror("open new file");
        return 0;
    }

    //进行复制
    char data[BUF_SIZE]={0};
    int ret;
    //      读取旧文件信息
    while( ret=fread(data,1,BUF_SIZE,fp) )
    {
        // printf("strlen : %ld\n",strlen(data));
        // printf("data : %s\n",data);
        //锁上//修改变量
        pthread_mutex_lock(&mutex);
        //写入新文件
        fwrite(data,ret,1,fp1);
        p_bar.already_read_file_size += ret;
        //解锁
        pthread_mutex_unlock(&mutex);
    }
    // printf("strlen1s : %ld\n",strlen(data));
    printf("[%s]已完成\n",pathbuffer1);
    fclose(fp);
    fclose(fp1);
    free(buf);
}



//读文件夹并丢入线程池
void read_dir(struct node *buf,thread_pool *pool)
{
    //打开文件夹
    DIR *dirp1=opendir(buf->DIRPATH1);
    if(dirp1==NULL){
        perror("open file");
        return;
    }

    struct node *buf_inside = malloc(sizeof(struct node));
    while ( buf->dir = readdir(dirp1) )
    {
        //找到一个文件夹
        if(buf->dir->d_type==DT_DIR && strcmp(buf->dir->d_name,".")!=0 && strcmp(buf->dir->d_name,"..")!=0 )
        {
            char pathbuffer1[strlen(buf->DIRPATH1)+strlen(buf->dir->d_name)+2];
            char pathbuffer2[strlen(buf->DIRPATH2)+strlen(buf->dir->d_name)+2];
            sprintf(pathbuffer1,"%s/%s",buf->DIRPATH1,buf->dir->d_name);
            sprintf(pathbuffer2,"%s/%s",buf->DIRPATH2,buf->dir->d_name);
#ifndef bar
            printf("[ ]创建文件夹\n");
#endif            
            int flag = mkdir(pathbuffer2,777);
            if(flag<0)
            {
                perror("mkdir");
                return;
            }

            //复制文件夹路径
            strcpy(buf_inside->DIRPATH1 ,pathbuffer1);
            strcpy(buf_inside->DIRPATH2 ,pathbuffer2);
            //递归打开文件
            read_dir(buf_inside,pool);
        }
        //找到一个非文件夹类型的文件
        else if( buf->dir->d_type!=DT_DIR )
        {
            //创建结构体存放文件信息
            struct node *new = malloc(sizeof(struct node));
            new->dir = buf->dir;
            strcpy(new->DIRPATH1,buf->DIRPATH1);
            // printf("new : %s/%s\n",new->DIRPATH1,new->dir->d_name);
            strcpy(new->DIRPATH2,buf->DIRPATH2);
            char filename[512];
            sprintf(filename,"%s/%s",new->DIRPATH1,new->dir->d_name);

            /* //获取文件大小
            struct stat statbuf;
            int ret = stat(filename,&statbuf);
            if(ret != 0)
            {
                perror("stat file size");
                return ;
            }
            p_bar.total_file_size += statbuf.st_size;
 */
            
            
            //投放任务
            add_task(pool,cp,new);

        }
    }
    sleep(1);

    closedir(dirp1);

    return;
}



/* 
void *progress_bar(void *arg)
{
    int row = 4,col = 30;
    int ret;
    while(1)
    {
        ret = (int) ( (float)p_bar.already_read_file_size/(float)p_bar.total_file_size*50 );
#ifdef bar
        printf("\033[2J");
        printf("\033[%d;%dH|",row,col+49);

        printf("\033[%d;%dH|",row,col);
        for(int i=0;i<ret;i++)
        {
            printf("#");
        }
        printf("\033[%d;%dH",row-2,col);
        for(int i=0;i<50;i++)
        {
            printf("_");
        }
        
        printf("\033[%d;%dH",row+2,col);
        for(int i=0;i<50;i++)
        {
            printf("_");
        }
        printf("\n");
        sleep(1);
#endif
    }

}



 */