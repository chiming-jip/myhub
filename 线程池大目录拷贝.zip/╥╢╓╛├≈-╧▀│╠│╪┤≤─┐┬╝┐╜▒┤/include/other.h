#ifndef _OTHER_H_
#define _OTHER_H_

#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>
#include "thread_pool.h"

struct node
{
    char DIRPATH1[256];
    char DIRPATH2[256];
    struct dirent * dir ;
};

struct progress_bar
{
    unsigned total_file_size;
    unsigned already_read_file_size;
}p_bar;

bool die;

pthread_mutex_t mutex;

void read_dir(struct node *buf,thread_pool *pool);
void *progress_bar(void *arg);


void * cp(void *buf);






#endif